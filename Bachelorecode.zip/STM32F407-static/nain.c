#include "main.h"

#include <stdio.h>



/*************************************************************PROLEAD Adaption******************************************************/
/***********************************************************************************************************************************/

// Function prototype
void initialize_local(UN_256bitValue *local_k, UN_256bitValue *local_p, const uint8_t global[64]);
void blindandcreatbf(UN_256bitValue *scalar, UN_256bitValue *blindingFactor);
static int computeY_curve25519_affine(fe25519* y, const fe25519* x);
int cipher(uint8_t *r, uint8_t *p );
int checkifxisapoint(fe25519* result, const fe25519* initialInput);
//void generate_random256bitvalue(UN_256bitValue *randomValue);

// Global variable, PROLEAD input
uint8_t input_s1[64] __attribute__((section(".data")));
uint32_t randomness __attribute__((section(".randomness")));

// Function to Generate random value of 256 bit but smaller then 2^253
void fe25519_generateRandomValueunder2pow253(fe25519* result) {
  randombytes(result->as_uint8_t, 32);
    // Ensure the generated number is smaller than 2^253
    result->as_uint8_t[31] &= 0x7F; // Clear the highest bit
    result->as_uint8_t[31] |= 0x01; // Set the second-highest bit to 1
}
// Function to calculate y from a point x
static int computeY_curve25519_affine(fe25519* y, const fe25519* x) {
  // y^2 = x^3 + 486662x^2 + x
  fe25519 tmp, x2;
  static const fe25519 CON486662 = {
    {0x06, 0x6d, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}};

  // x^3
  fe25519_square(&x2, x);
  fe25519_mul(&tmp, &x2, x);
  // 486662x^2
  fe25519_mul(&x2, &x2, &CON486662);

  fe25519_add(&tmp, &tmp, &x2);
  fe25519_add(&tmp, &tmp, x);

  return fe25519_squareroot(y, &tmp);
}
//Function to localize the variables and put them into unions of 256 bit.
void __attribute__((noinline)) initialize_local(UN_256bitValue *local_k, UN_256bitValue *local_p, const uint8_t global[64]) {
  for (int i = 0; i < 32; i++) {
  local_k->as_uint8_t[i] = global[i];
  }
  for (int i = 0; i < 32; i++) {
  local_p->as_uint8_t[i] = global[i+32];
  }
}
//Function to check if the inputed x is a point on the curve and also generate a new random x if it is not.
int checkifxisapoint(fe25519* input) {
    int maxAttempts = 1000;  // Set a limit to avoid infinite loops
    f25519 result;
    for (int attempt = 0; attempt < maxAttempts; attempt++) {
        int retval = computeY_curve25519_affine(&result, input);
        if (retval == 0) {
            // Successfully found the square root
            return 0;
        } else {
            // Modify the input and try again
           fe25519_generateRandomValueunder2pow253(input) 
            
        }
    }

    // If the loop reaches this point, it means no square root was found
    return -1;
}

//Function to randomize the point blinding R and S
// Calculate R and S.
void randomizepointblinding(fe25519* Rx, fe25519* Ry,fe25519*Rz,fe25519*Sx,fe25519*Sy,fe25519*Sz)
 {
  // creat strcuts and save the points R and S
  point25519 R, S;
  R.x = Rx;
  R.y = Ry;
  R.z = Rz;
  S.x = Sx;
  S.y = Sy;
  S.z = Sz;
  // creat structs to add onto R and S
  point25519 R0, S0;
  fe25519 rx0, ry0, rz0, sx0, sy0, sz0;
  R0.x = &rx0;
  R0.y = &ry0;
  R0.z = &rz0;
  S0.x = &sx0;
  S0.y = &sy0;
  S0.z = &sz0;
  fe25519_cpy(R0.x, R.x);
  fe25519_cpy(R0.y, R.y);
  fe25519_cpy(R0.z, R.z);
  fe25519_cpy(S0.x, S.x);
  fe25519_cpy(S0.y, S.y);
  fe25519_cpy(S0.z, S.z);

  uint16_t randbyte;
  randombytes(&randbyte, 1);
  int16_t nextBit = 13;
  while (nextBit >= 0) {
    curve25519_doublePoint(&R, &R);
    curve25519_doublePoint(&S, &S);
    if (randbyte & (1 << nextBit)) {
      curve25519_addPoint(&R, &R, &R0);
      curve25519_addPoint(&S, &S, &S0);
    }
    nextBit--;
  }
 //Set the new blinding Points to be used
  *Rx = R.x;
  *Ry = R.y;
  *Rz = R.z;
  *Sx = S.x;
  *Sy = S.y;
  *Sz = S.z;
}

//Function to renew Blinding factor and inverse blinding factor taken from the original code and adapted to our needs
void blindandcreatbf(UN_256bitValue *scalar, UN_256bitValue *blindingFactor){

   UN_256bitValue newBlindingFactor, newBlindingFactorInverse;
  fe25519_setzero(&newBlindingFactor);

  // new code so newBlindingFactor is not 0
  // unsigned long long;
  do {
    randombytes(newBlindingFactor.as_uint8_t, 8);
  } while (!newBlindingFactor.as_64_bitValue_t[0].as_uint64_t[0]);
  //! fe25519_iszero(&newBlindingFactor)

  fe25519 t, randB;                                    //---------------------------------
  UN_512bitValue randVal;                              //         
  randombytes(randVal.as_uint8_t, 64);                 //
  fe25519_reduceTo256Bits(&randB, &randVal);           //  calculate new blinding factor
  sc25519_mul(&t, &newBlindingFactor, &randB);         // 
  sc25519_inverse(&t, &t);                             //         
  sc25519_mul(&newBlindingFactorInverse, &t, &randB);  //---------------------------------
  sc25519_mul(scalar, scalar, &newBlindingFactorInverse); // s_(f-1) = s*f^(-1), blindes the scalar inputed with the inverse blinding factor
  // sc25519_mul(scalar, scalar, blindingFactor); // not needed since the inputed scalar is not blinded, uncomment if the scalar is blinded         
  cpy_256bitvalue(blindingFactor, &newBlindingFactor); //writes the generate blinding factor into the input variable
}

int __attribute__((noinline)) cipher(uint8_t *r, uint8_t *p ){
  return crypto_scalarmult_curve25519(r, p);

}

/***********************************************************************************************************************************/
/************************************Point X_p**************************************************************************************/
// Input XP variables
UN_256bitValue uXp; // randomly generated point X_p

/***********************************Secure Input from Alg 3.*************************************************************************/
// Key variables
UN_256bitValue ustatic_key;  // key k
UN_256bitValue ublindingFactor; // blinding factor f

//Point blinding points


 /**************Point blinding R**********************/

UN_256bitValue uRx = {{0x0f, 0x52, 0x4b, 0xef, 0x7e, 0x12, 0x25, 0x8f,
                       0xd9, 0xee, 0xfc, 0xd9, 0xe4, 0x68, 0xb2, 0x1e,
                       0x54, 0x3d, 0x90, 0xcc, 0x4a, 0x54, 0xb3, 0x47,
                       0xf4, 0x8c, 0xc5, 0x96, 0x9f, 0xeb, 0xf4, 0x32}}; 
UN_256bitValue uRy = {{0xb8, 0x00, 0xed, 0x3e, 0xe5, 0xc6, 0x7f, 0xa7,
                       0x53, 0x28, 0x30, 0x59, 0x44, 0xdd, 0x5a, 0x89,
                       0x66, 0x3f, 0x60, 0xdd, 0xcc, 0x1e, 0x48, 0xbb,
                       0xe0, 0xf5, 0x5b, 0x19, 0x25, 0x30, 0x9d, 0x17}};
UN_256bitValue uRz = {{0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}; //the z variable is 1 in projective coordinates

/**************Point blinding S**********************/

UN_256bitValue uSx = {{0x96, 0xbb, 0x65, 0x32, 0x04, 0x20, 0xa1, 0x8f,
                       0x53, 0x04, 0x2c, 0x0e, 0xdd, 0x51, 0xdb, 0xdd,
                       0xac, 0xf0, 0xb9, 0x65, 0x2f, 0x77, 0x44, 0x92,
                       0x64, 0xeb, 0xa9, 0x68, 0x35, 0xad, 0x83, 0x53}};
UN_256bitValue uSy = {{0x36, 0xd0, 0xaa, 0x8c, 0xfe, 0x37, 0x34, 0x3f,
                       0x51, 0x27, 0x1d, 0xdb, 0x4b, 0xd4, 0x0f, 0xd3,
                       0x62, 0x70, 0x80, 0xa0, 0xe5, 0x5c, 0x48, 0x5f,
                       0xdf, 0x4a, 0x4f, 0x53, 0xe2, 0x8b, 0x61, 0x32}};
UN_256bitValue uSz={{0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}};               
 //the z variable is 1 in projective coordinates
/**********************************************************************************************************************************/
/**********************************************************************************************************************************/                       

int main(void) {


 //Step 1 :localize Values, writes the values from PROLEAD into the unions 
  initialize_local(&ustatic_key, &uxp, input_s1); 
 //Step 2: check if Xp is a point on the curve if not generate a new one
checkifxisapoint(&uXp);
 //Step 3: randomize point blinding R and S
 randomizepointblinding(&uRx, &uRy, &uSz, &uSx, &uSy, &uSz);
 //Step 5: renew blinding factor(&unbstatic_key, &ublindingFactor);
 blindandcreatbf(&ustatic_key, &ublindingFactor);

  set_static_key_curve25519(uRx.as_uint8_t, uRy.as_uint8_t, uRz.as_uint8_t,
                            uSx.as_uint8_t, uSy.as_uint8_t, uSz.as_uint8_t,
                            ustatic_key.as_uint8_t, ublindingFactor.as_uint8_t);
 
 // to save result of cipher X_[k]p= X_p*k
 uint8_t result[32];

 cipher(result, uXpx.as_uint_t);  //call cipher function


  

  return 0;
}